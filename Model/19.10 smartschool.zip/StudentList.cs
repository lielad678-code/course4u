﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class StudentList : List<Student>
    {
        public StudentList()
        {

        }

        public StudentList(IEnumerable<Student> students) : base(students) { } 
        public StudentList(IEnumerable<BaseEntity> students)
            : base(students.Cast<Student>().ToList()) { }


    }
}
