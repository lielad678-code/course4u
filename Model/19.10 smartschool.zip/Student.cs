﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Student : User 
    {

        private string address;
        private string name;
        private string firstName;
        private string lastName;
        private string phoneNumber;
        private string email;
        private string birthDate;
        private string gender;


        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }


        public string Name
        {
            set { name =  value; }
            get { return name; }
        }
        public string Address
        {
            set { address = value; }
            get { return address; }
        }

        public string Gender { get => gender; set => gender = value; }
        public string BirthDate { get => birthDate; set => birthDate = value; }
        public string Email { get => email; set => email = value; }
    }
}
