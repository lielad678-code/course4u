﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Subject
    {
        private string subjects;
        private int units;

        public string Subjects { get => subjects; set => subjects = value; }
        public int Units { get => units; set => units = value; }
    }
}
